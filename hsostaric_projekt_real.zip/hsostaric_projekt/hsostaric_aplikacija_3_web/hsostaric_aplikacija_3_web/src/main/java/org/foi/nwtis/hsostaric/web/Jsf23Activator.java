package org.foi.nwtis.hsostaric.web;


import javax.enterprise.context.ApplicationScoped;
import javax.faces.annotation.FacesConfig;


@ApplicationScoped
@FacesConfig(version = FacesConfig.Version.JSF_2_3)
public class Jsf23Activator {
    
}
